const { app, BrowserWindow, globalShortcut, screen } = require('electron');
const path = require('path');

let win; // make it global so F9 can access it
let isVisible = true;

function createWindow() {
  const { workArea } = screen.getPrimaryDisplay();

  const winWidth = Math.floor(360 * 2 / 3); // = 213
  const winHeight = Math.floor(1100 * 2 / 3); // ≈ 666

  win = new BrowserWindow({
    width: winWidth,
    height: winHeight,
    x: 2560 - winWidth, // old fixed value
    y: 0,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    resizable: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  win.setIgnoreMouseEvents(false);
  win.loadFile('index.html');

  win.webContents.on('before-input-event', (event, input) => {
    if (input.key === 'F12' && input.type === 'keyDown') {
      win.webContents.toggleDevTools();
    }
  });
}

app.whenReady().then(() => {
  createWindow();

  // F9 to toggle overlay visibility
  globalShortcut.register('F9', () => {
    isVisible = !isVisible;
    if (isVisible) {
      win.show();
    } else {
      win.hide();
    }
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});
