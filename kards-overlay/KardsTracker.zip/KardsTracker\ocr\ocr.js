const Tesseract = require('tesseract.js');
const path = require('path');

const imagePath = path.join(__dirname, 'test.png');

Tesseract.recognize(imagePath, 'eng', {
  logger: m => console.log(m)
}).then(({ data: { text } }) => {
  console.log('\n--- OCR Result ---\n');
  console.log(text);
}).catch(err => {
  console.error('OCR failed:', err);
});
