const fs = require('fs');
const path = require('path');

console.log("RENDERER LOADED");

let cardState = [];
const decksPath = path.join(__dirname, 'decks');

// Load selected deck from JSON
function loadDeck(fileName) {
  const fullPath = path.join(decksPath, fileName);
  const raw = fs.readFileSync(fullPath);
  const deck = JSON.parse(raw);
  cardState = (deck.cards || deck).map(card => ({ ...card, played: 0 }));
  render();
}

// Render UI
function render() {
  const container = document.getElementById('cardList');
  container.innerHTML = '';

  const sortedCards = [...cardState].sort((a, b) => a.kredit - b.kredit);
  const hideUsed = document.getElementById('hideUsed').checked;
    // Calculate total and remaining cards
  const total = cardState.reduce((sum, card) => sum + card.count, 0);
  const remaining = cardState.reduce((sum, card) => sum + (card.count - card.played), 0);

  // Update card count display
  const display = document.getElementById('cardCountDisplay');
  if (display) display.textContent = `${total}/${remaining}`;


  sortedCards.forEach((card) => {
    const remaining = card.count - card.played;
    if (hideUsed && remaining === 0) return; // skip rendering used cards

    const div = document.createElement('div');
    div.className = 'cardEntry';

    if (remaining === 0) {
      div.classList.add('used');
    }

    div.innerHTML = `<span class="kredit">[${card.kredit}]</span> ${card.name} (${remaining}/${card.count})`;

    div.onclick = () => {
      if (card.played < card.count) {
        card.played++;
      } else {
        card.played = 0;
      }
      render();
    };

    div.oncontextmenu = (e) => {
      e.preventDefault();
      if (card.played > 0) card.played--;
      render();
    };

    container.appendChild(div);
  });
}


// Load deck dropdown
function loadDeckList() {
  const select = document.getElementById('deckSelect');
  select.innerHTML = ''; // clear old

  const files = fs.readdirSync(decksPath).filter(f => f.endsWith('.json'));
  console.log("Decks path:", decksPath);
  console.log("Files found in /decks:", files);

  if (files.length === 0) {
    select.innerHTML = '<option disabled>No decks found</option>';
    return;
  }

  files.forEach(file => {
    const option = document.createElement('option');
    option.value = file;
    option.textContent = file.replace('.json', '');
    select.appendChild(option);
  });

  select.value = files[0];
  loadDeck(files[0]);

  select.onchange = () => {
    loadDeck(select.value);
  };
}

// Reset button
document.getElementById('resetBtn').onclick = () => {
  cardState.forEach(card => card.played = 0);
  render();
};

// Drag & Drop Import Box
const importBox = document.getElementById('importBox');

importBox.addEventListener('dragover', (e) => {
  e.preventDefault();
  importBox.classList.add('dragover');
});

importBox.addEventListener('dragleave', () => {
  importBox.classList.remove('dragover');
});

importBox.addEventListener('drop', (e) => {
  e.preventDefault();
  importBox.classList.remove('dragover');

  const file = e.dataTransfer.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    const content = event.target.result;
    const deckData = parseKardsTxtDeck(content);

    if (!deckData || !deckData.cards.length) {
      alert("Failed to parse deck.");
      return;
    }

    const deckFileName = deckData.name.replace(/\s+/g, '_') + '.json';
    const filePath = path.join(decksPath, deckFileName);
    fs.writeFileSync(filePath, JSON.stringify(deckData, null, 2));

    loadDeckList(); // reload dropdown
    setTimeout(() => {
      document.getElementById('deckSelect').value = deckFileName;
      loadDeck(deckFileName);

    }, 200);
  };
  reader.readAsText(file);
});

// Parse original KARDS deck format
function parseKardsTxtDeck(raw) {
  const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);
  let name = lines[0] || 'Imported Deck';
  const cards = [];

  for (let line of lines) {
    const match = line.match(/^(\d+)x\s+\((\d+)K\)\s+(.+)$/i);
    if (match) {
      const count = parseInt(match[1]);
      const kredit = parseInt(match[2]);
      const cardName = match[3].trim();
      cards.push({ name: cardName, kredit, count, played: 0 });
    }
  }

  return { name, cards };
}


loadDeckList();

const renameBtn = document.getElementById('renameBtn');
const renameGroup = document.getElementById('renameGroup');
const confirmRenameBtn = document.getElementById('confirmRenameBtn');
const renameInput = document.getElementById('renameInput');
const deckSelect = document.getElementById('deckSelect');

renameBtn.onclick = () => {
  renameGroup.style.display = 'inline-block';
  renameInput.focus();
};

confirmRenameBtn.onclick = () => {
  const oldFileName = deckSelect.value;
  const newRaw = renameInput.value.trim();
  if (!oldFileName || !newRaw) return;

  const newFileName = newRaw.replace(/\s+/g, '_') + '.json';
  const oldPath = path.join(decksPath, oldFileName);
  const newPath = path.join(decksPath, newFileName);

  if (fs.existsSync(newPath)) {
    alert("A deck with that name already exists.");
    return;
  }

  try {
    const data = JSON.parse(fs.readFileSync(oldPath));
    if (data.name) data.name = newRaw;

    fs.writeFileSync(newPath, JSON.stringify(data, null, 2));
    fs.unlinkSync(oldPath);

    loadDeckList();
    setTimeout(() => {
      document.getElementById('deckSelect').value = newFileName;
      loadDeck(newFileName);
    }, 200);

    renameInput.value = '';
    renameGroup.style.display = 'none';
  } catch (err) {
    alert("Rename failed: " + err.message);
  }
};
